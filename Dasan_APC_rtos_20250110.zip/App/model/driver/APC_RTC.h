/*
 * APC_RTC.h
 *
 *  Created on: 2023. 10. 5.
 *      Author: Yongseok
 */

#ifndef _APC_RTC_H_
#define _APC_RTC_H_

#include "APC_Define.h"

void getRtcTime();
void setRtcTime();

#endif /* _APC_RTC_H_ */
